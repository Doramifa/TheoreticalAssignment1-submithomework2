import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainOutPut {

	public static void main(String[] args) {
		processScoreTable("F:\\eclipse\\TheoreticalAssignment1\\xiaohao.txt");
	}
	
	
public static void processScoreTable(String filePath){
	BufferedReader br = null;
	try {
	   br = new BufferedReader(new FileReader(filePath));
	  } catch (FileNotFoundException e) {
	   e.printStackTrace();
	   return;
}
	String []columnName = {"����","��ͷ��" ,"�γ�����", "�γ�����", "ѧ��", "��ʦ","�ڿ�ѧԺ","ѧϰ����","ѧ��","ѧ��","�ɼ�"}; //����
	int []courseIndexs = {4, 10};          //���ݶ�Ӧ����
	int i,j,index;
	
	
	String line;
	List<Map<String, Object>> courses = new ArrayList<Map<String, Object>>();
	List<Map<String, Object>> sortList = new ArrayList<Map<String, Object>>();
	try {
		br.readLine(); 
		while((line = br.readLine()) != null){
			index = 0;
			String []se = line.split(" ");
			Map<String, Object> course = new HashMap<String, Object>();
			for(i = 0; i < se.length; i++){
				if("".equals(se[i])){
					continue;
		     }
				if(index >= columnName.length){
					continue;
		     }
				course.put(columnName[index], se[i]);
				index++;
		    }
			
		    //�����Ȩƽ����
			/*double total=0;
		    for(j = 0; j < se.length; j++){
		        total += Double.parseDouble((String) course.get(columnName[courseIndexs[1]]));
		       }
		    double average = total / 50;
		    //ֻȡһλС��
		    average = Math.round(average * 10)/10;
		    course.put("Total", total);
		    course.put("Average", average);*/
		       
		    Map<String, Object> sort = new HashMap<String, Object>();
		    sort.put("Id", course.get("Id"));
		    sort.put("Total", course.get("Total"));
		    sortList.add(sort);
		       
		    courses.add(course);
		    }
		    br.close();
		      
		    
		    
		    //����
		     /*for(i = 0; i < sortList.size(); i++){
		       for(j = i + 1; j < sortList.size(); j++){
		        if((Double)sortList.get(i).get("Total") < (Double)sortList.get(j).get("Total")){
		         Map<String, Object> temp = sortList.get(i);
		         sortList.set(i, sortList.get(j));
		         sortList.set(j, temp);
		        }
		       }
		      }
		      Map<Object, Integer> sortedId = new HashMap<Object, Integer>();
		      for(i = 0; i < sortList.size(); i++){
		       sortedId.put(sortList.get(i).get("Id"), i+1);
		      }
		      */
		      
		      
		    
		    
		      //���(д�������ļ�)
		      PrintWriter pw = new PrintWriter(new File("F:\\eclipse\\TheoreticalAssignment1\\new.txt"));
		      
		      pw.println("����\t��ͷ��\t�γ�����\t�γ�����\tѧ��\t��ʦ\t�ڿ�ѧԺ\tѧϰ����\tѧ��\tѧ��\t�ɼ�\t����\t��Ȩƽ����");
		      int cIndex;
		      for(i = 0; i < courses.size(); i++){
		       Map<String, Object> st = courses.get(i);
		       cIndex = 0;
		       pw.println(st.get(columnName[cIndex++]) + "\t" + st.get("Average"));
		        }
		      pw.flush();
		      pw.close();
		} catch (IOException e) {
		      e.printStackTrace();
		     }
		    }
}







